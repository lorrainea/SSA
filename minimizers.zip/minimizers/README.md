minimizers
===

<b>Installation</b>: To install and compile minimizers follow the instructions within each folder.

<b>INPUT</b>: A file containing a single text.

<b>OUTPUT</b>: A file containing the positions of all minimizers.


```
Usage: 

./minimizers <text_file> <window_size> <k> <output_filename>

<text_file> - name of input text file
<window_size> - size of the window
<k> - minimizer size
<output_filename> - name of output file where minimizers will be placed
```

<b>Example</b>
```
 $ ./minimizers ./data/text 8 3 out
```

