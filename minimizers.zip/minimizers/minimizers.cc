#include <math.h>
#include <chrono>
#include <random>
#include <algorithm>
#include <unordered_set>
#include <unordered_map>
#include <sdsl/bit_vectors.hpp>                                
#include <sdsl/rmq_support.hpp>	
#include <sdsl/io.hpp> 

using namespace std;
using namespace sdsl;

#ifdef _USE_64
#include <divsufsort64.h>
typedef int64_t INT;                                     
#endif

#ifdef _USE_32
#include <divsufsort.h>
typedef int32_t INT;                                      	
#endif

bool increasing(pair<INT,INT>& a, pair<INT,INT>& b)
{
    return( a.second < b.second );
}

bool decreasing(pair<INT,INT>& a, pair<INT,INT>& b)
{
    return( a.second > b.second );
}

/* Kasai et al algorithm for O(n)-time LCP construction */
INT LCParray ( unsigned char * text, INT n, INT * SA, INT * ISA, INT * LCP )
{
        INT i=0, j=0;

        LCP[0] = 0;
        for ( i = 0; i < n; i++ ) // compute LCP[ISA[i]]
                if ( ISA[i] != 0 )
                {
                        if ( i == 0) j = 0;
                        else j = (LCP[ISA[i-1]] >= 2) ? LCP[ISA[i-1]]-1 : 0;
                        while ( text[i+j] == text[SA[ISA[i]-1]+j] )
                                j++;
                        LCP[ISA[i]] = j;
                }
        return ( 1 );
}


/* Computes the minimizers of a string of length n in O(n) time */
INT compute_minimizers(  INT * rank, INT n, INT w, INT k, unordered_set<INT> &minimizers  )	
{
	
	deque<pair<INT,INT>> min_rank = {};
	
	// minimum rank in first window
   	for (INT j = 0; j <= w - k ; j++) 
   	{
 		while ( !min_rank.empty() && rank[j] < min_rank.back().first )
 			min_rank.pop_back();
				
		min_rank.push_back(std::make_pair(rank[j], j));
    	}
    	
	minimizers.insert( min_rank.at(0).second );

	
	// minium rank in remaining windows
	for( INT i = w-k+1; i<=n-k; i++ )
	{
		while (!min_rank.empty() && min_rank.back().first > rank[i])
			min_rank.pop_back();

				
		min_rank.push_back(std::make_pair(rank[i], i));
		
	
		while( !min_rank.empty() && min_rank.front().second < i-w+k )
		{
			min_rank.pop_front();
		}	
		
			
		minimizers.insert( min_rank.at(0).second );

	}
	
	return 0;
}


/* Computes orderings of an alphabet */
INT compute_orderings(  unsigned char * seq, INT w, INT k, unordered_set<INT> &minimizers, INT * SA, INT * LCP, INT * invSA, INT * rank, const char * output_filename  )
{
	INT n = strlen ( (char*) seq );

	/* Compute suffix array */
	#ifdef _USE_64
  	if( divsufsort64( seq, SA,  n ) != 0 )
  	{
  		fprintf(stderr, " Error: SA computation failed.\n" );
          	exit( EXIT_FAILURE );
  	}
	#endif

	#ifdef _USE_32
  	if( divsufsort( seq, SA,  n ) != 0 )
  	{
  		fprintf(stderr, " Error: SA computation failed.\n" );
          	exit( EXIT_FAILURE );
  	}
	#endif
	

	for ( INT i = 0; i < n; i ++ )
	{
	        invSA [SA[i]] = i;
	        
	}

	/* Compute the LCP array */
	if( LCParray( seq, n, SA, invSA, LCP ) != 1 )
	{
	        fprintf(stderr, " Error: LCP computation failed.\n" );
	        exit( EXIT_FAILURE );
	}


	INT rank_count =  0;	
	rank[SA[0]] = rank_count;
		
	/* Compute the ranks */
	for(INT j =1; j<n; j++)
	{
		if( LCP[j] >= k )
		{
			
			rank[SA[j]] = rank_count;
		}
		else 
		{
			rank_count++;
			rank[SA[j]] = rank_count;
		}
		
	}	
	
	ofstream minimizers_output;
	minimizers_output.open(output_filename);

	
	unordered_map<INT,INT> * frequency = new unordered_map<INT,INT>();
	unordered_map<INT,INT> * mapping = new unordered_map<INT,INT>();
	
	// Identify frequency of alphabet
	for(INT i = 0; i<=n-k; i++)
	{
		auto it = frequency->find(rank[i]);
  		if (it != frequency->end())
    		{
    			it->second = it->second + 1;
		}
		else frequency->insert( pair<INT,INT>( rank[i], 1 ) );
	} 	
		 
	double min = n;
	double max = 0;
	INT * new_rank =  ( INT * ) malloc( ( n  ) *  sizeof( INT ) );
	
	vector<pair<INT,INT>> * order = new vector<pair<INT,INT>>();
	
	for (auto it = frequency->begin(); it != frequency->end(); it++)
	{	
		order->push_back( make_pair<INT,INT>( (INT) it->first, (INT) it->second) );
	}
	
	// Find new orderings based on frequency (decreasing)
	std::sort( order->begin(), order->end(), decreasing );
	
	// Initial mapping
	for (INT i = 0; i<order->size(); i++)
	{
		mapping->insert( { order->at(i).first, i } );
	}
	
	// Create a mapping of character to index position
	for (INT i = 0; i<order->size(); i++)
	{
		// Swap position of i with index 0 within the map
		if( i > 0 )
		{
			auto pos_i_1 = mapping->extract( order->at(i-1).first );
			auto pos_i = mapping->extract( order->at(i).first );
			
			INT pos_i_1_key = pos_i_1.key();
			INT pos_i_key = pos_i.key();
			
			pos_i_1.key() = pos_i_key;
			mapping->insert(move(pos_i_1));
			
			pos_i.key() = pos_i_1_key;
			mapping->insert(move(pos_i));
		}
		
		// Create new rank sequence
		for( INT j = 0; j<=n-k; j++)
		{
			 new_rank[j] = mapping->find( rank[j] )->second; 
		}
		
		compute_minimizers( new_rank, n, w, k, minimizers  );
		
		if( minimizers.size() > max )
		{
			max = minimizers.size();
			minimizers_output<<max<<" "<<min<<endl;
		}
			
		if( minimizers.size() < min )
		{
			min = minimizers.size();
			minimizers_output<<max<<" "<<min<<endl;
		}
		
		minimizers.clear();		
	}

	order->clear();
	mapping->clear();
	
	for (auto it = frequency->begin(); it != frequency->end(); it++)
	{
		order->push_back( make_pair<INT,INT>( (INT) it->first, (INT) it->second) );

	}
	
	// Find new orderings based on frequency (increasing)
	std::sort( order->begin(), order->end(), increasing );
	
	// Initial mapping
	for (INT i = 0; i<order->size(); i++)
	{
		mapping->insert( { order->at(i).first, i } );
	}
	
	// Create a mapping of character to index position
	for (INT i = 0; i<order->size(); i++)
	{
		if( i > 0 )
		{
			auto pos_i_1 = mapping->extract( order->at(i-1).first );
			auto pos_i = mapping->extract( order->at(i).first );
			
			INT pos_i_1_key = pos_i_1.key();
			INT pos_i_key = pos_i.key();
			
			pos_i_1.key() = pos_i_key;
			mapping->insert(move(pos_i_1));
			
			pos_i.key() = pos_i_1_key;
			mapping->insert(move(pos_i));
		}
		
		
		// Create new rank sequence
		for( INT i = 0; i<=n-k; i++)
		{
			 new_rank[i] = mapping->find( rank[i] )->second; 
		}
		
		compute_minimizers( new_rank, n, w, k, minimizers  );
				
	
			
		if( minimizers.size() > max )
		{
			max = minimizers.size();
			minimizers_output<<max<<" "<<min<<endl;
		}
			
		if( minimizers.size() < min )
		{
			min = minimizers.size();
			minimizers_output<<max<<" "<<min<<endl;
		}
		
		minimizers.clear();	
	}

	mapping->clear();
	double diff =  min/ max;
	random_device rd;
	mt19937 g(rd());
        
	cout<<"Random generation starts to improve the result!\n";
	
	while( diff > 0.5 )
	{
		shuffle( order->begin(), order->end(), g);
		
		for (INT i = 0; i< order->size(); i++ )
		{
			mapping->insert( { order->at(i).first, i } );
		}
		
		// Create new rank sequence
		for( INT i = 0; i<=n-k; i++)
		{
			 new_rank[i] = mapping->find( rank[i] )->second; 
		}
		
		compute_minimizers( new_rank, n, w, k, minimizers  );
				
		
		if( minimizers.size() > max )
		{
			max = minimizers.size();
			minimizers_output<<max<<" "<<min<<endl;
		}
			
		if( minimizers.size() < min )
		{
			min = minimizers.size();
			minimizers_output<<max<<" "<<min<<endl;
		}
		
		minimizers.clear();
		mapping->clear();
		diff = min/max;
		
	}

	minimizers_output.close();
	delete(frequency);
	delete(order);
	delete(mapping);
	free(new_rank);
	
return 0;
	
}	


int main(int argc, char **argv)
{

	if( argc < 5 )
 	{
        	cout<<"Wrong arguments!\n";
 		cout<<"./minimizers <text_file> <window_size> <k> <output_filename>\n";
 		exit(-1);
 	}
 	
 	ifstream is;
 	is.open(argv[1], ios::in | ios::binary);

 	std::string str2(argv[2]);
	std::string str3(argv[3]);
	
 	ifstream is2;
 	is2.open (argv[3], ios::in | ios::binary);

 	INT window;
 	std::stringstream(str2)>>window;
 	
 	INT k;
 	std::stringstream(str3)>>k;
 	
 	char * output_filename; 
 	output_filename = (char *) malloc(strlen(argv[4])+1);    
    	strcpy(output_filename,argv[4]);
	
 	ifstream in_file(argv[1], ios::binary);
   	in_file.seekg(0, ios::end);
	INT text_file_size = in_file.tellg();
  	
   	INT w = window + k - 1;
   	unsigned char * text = ( unsigned char * ) malloc (  ( text_file_size + 1 ) * sizeof ( unsigned char ) );	
   	
  	char c = 0;
  	INT text_size = 0;
	for (INT i = 0; i < text_file_size; i++)
	{	
		is.read(reinterpret_cast<char*>(&c), 1);
		if( (unsigned char) c == '\n')
			continue;
		else
		{
			text[text_size] = (unsigned char) c ;
			text_size++;
		}
		
	}
	in_file.close();
	text[text_size] = '\0';
	
	if( w - k - 1 < 0 )
		k = 2;
	
	if( text_size < w )
	{
	
		fprintf( stderr, " Error: Window size (w) cannot be larger than sequence length!\n");
		return ( 1 );
	}


 	unordered_set<INT> minimizers;
	 	
	INT * SA;
	INT * LCP;
	INT * invSA;
	INT * rank;
		
	rank = ( INT * ) malloc( ( text_file_size  ) *  sizeof( INT ) );
	SA = ( INT * ) malloc( ( text_file_size ) * sizeof( INT ) );

		
	if( ( SA == NULL) )
	{
		fprintf(stderr, " Error: Cannot allocate memory for SA.\n" );
		return ( 0 );
	}
		
	/* Compute the inverse SA array for block */
	invSA = ( INT * ) calloc( text_file_size , sizeof( INT ) );
	if( ( invSA == NULL) )
	{
		fprintf(stderr, " Error: Cannot allocate memory for invSA.\n" );
		return ( 0 );
	}
		
	LCP = ( INT * ) calloc  ( text_file_size, sizeof( INT ) );
	if( ( LCP == NULL) )
	{
		fprintf(stderr, " Error: Cannot allocate memory for LCP.\n" );
		return ( 0 );
	}
	  		
	ifstream is_block;
	is_block.open (argv[1], ios::in | ios::binary);
	  	  
	compute_orderings( text, w, k, minimizers, SA, LCP, invSA, rank, output_filename );

	free( text );
	free( SA );
	free( invSA );
	free( LCP );
	free( rank );
		
		
	return 0;
}
