./minimizers 100K 256 24 256.24.e.out
./minimizers 100K 256 26 256.26.e.out
./minimizers 100K 256 28 256.28.e.out
./minimizers 100K 256 30 256.30.e.out
./minimizers 100K 256 32 256.32.e.out
